# HelloWord
### I have course serverless aws

### that i have?

#### code serverless, ready for deploy

## execute server offline
install global
```
  npm i -g serverless
```

command 

```
  npm run dev
```