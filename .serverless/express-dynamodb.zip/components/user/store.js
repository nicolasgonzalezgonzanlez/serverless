const DB = require('../instanceMongoDB')
const TableName = process.env.tableName

const createdUser = (data) => {
  try {
    console.log(data)
    const params = {
      TableName,
      Item: data
    }
    console.log(DB)
    DB.put(params, (err) => {
      if (err) return { status: 400, message: 'No se ha podido crear el usuario' }
      else return { status: 201, message: 'Usuario creado exitosamente' }
    })
  } catch (err) {
     return {status: 400, message: err }
  }
}
module.exports = {
  createdUser
}